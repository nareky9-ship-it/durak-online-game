# Durak Online

A real-time two-player Durak web game with public/private rooms, 14/16/24/36/52-card decks, Fair and Liar modes, virtual chips, reactions, turn timers, and rematches.

## Run locally
1. Install Node.js 18 or newer.
2. In this folder run `npm install`.
3. Run `npm start`.
4. Open `http://localhost:3000` in two browser windows to test multiplayer.

## Deploy free on Render
1. Push this folder to a GitHub repository.
2. In Render choose **New → Blueprint** and connect the repository (or create a Web Service).
3. Render reads `render.yaml`; build command is `npm install`, start command is `npm start`.
4. Open the generated Render URL in two browsers to play.

## About Vercel
The Socket.io game server requires a persistent Node.js process. Standard Vercel serverless functions are not a suitable host for this server. Deploy this complete project to Render (or another persistent Node host). You can host a separate static landing page on Vercel if desired.

## Notes / next production steps
- Room state and player chips are currently in memory; a server restart clears rooms and balances.
- The included 14-card mini deck is a custom exact-14 variant: J/Q/K/A in three suits plus two tens.
- This starter implements two-player Podkidnoy-style play. A production release should add persistent accounts, reconnect tokens, Redis-backed room state for multiple server instances, anti-cheat/rate limiting, and a complete multi-player rules engine.
- Virtual chips have no cash value. No payments or real-money betting are included.
