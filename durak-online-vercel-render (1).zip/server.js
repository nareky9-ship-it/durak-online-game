const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
app.use(express.static("public"));
app.get("/health", (_, res) => res.json({ ok: true, service: "Durak Online" }));

const PORT = process.env.PORT || 3000;
const rooms = new Map();
const profiles = new Map();
const SUITS = ["♠", "♥", "♦", "♣"];
const RANKS = ["6","7","8","9","10","J","Q","K","A"];
const VALUE = Object.fromEntries(RANKS.map((r,i)=>[r,i]));
const timers = new Map();

function makeDeck(size) {
  let cards = [];
  let ranks = size === 52 ? ["2","3","4","5","6","7","8","9","10","J","Q","K","A"]
    : size === 36 ? ["6","7","8","9","10","J","Q","K","A"]
    : size === 24 ? ["9","10","J","Q","K","A"]
    : size === 16 ? ["J","Q","K","A"] : null;
  if (size === 14) {
    // Exact 14-card variant: J/Q/K/A in three suits, plus two tens.
    cards = ["♠","♥","♦"].flatMap(s => ["J","Q","K","A"].map(r => ({ id: crypto.randomUUID(), rank:r, suit:s })));
    cards.push({id:crypto.randomUUID(),rank:"10",suit:"♠"},{id:crypto.randomUUID(),rank:"10",suit:"♣"});
  } else {
    cards = ranks.flatMap(r => SUITS.map(s => ({ id:crypto.randomUUID(), rank:r, suit:s })));
  }
  for (let i=cards.length-1;i>0;i--) { const j=Math.floor(Math.random()*(i+1)); [cards[i],cards[j]]=[cards[j],cards[i]]; }
  return cards;
}
const code = () => crypto.randomBytes(3).toString("hex").toUpperCase();
const safeCard = c => ({ id:c.id, rank:c.rank, suit:c.suit });
const isRed = s => s === "♥" || s === "♦";
function publicState(room) {
  return {
    code: room.code, privacy: room.privacy, deckSize: room.deckSize, mode: room.mode,
    bet: room.bet, status: room.status, players: room.players.map(p=>({
      id:p.id, name:p.name, avatar:p.avatar, coins:p.coins, handCount:p.hand.length,
      connected:p.connected, isDefender:p.id===room.defenderId
    })),
    you: null, table: room.table.map(pair=>({
      attack: safeCard(pair.attack), defense: pair.defense ? safeCard(pair.defense) : null,
      challenged: !!pair.challenged, challengeable: !!pair.challengeable,
      playedBy: pair.playedBy
    })),
    trump: room.trump ? safeCard(room.trump) : null,
    deckCount: room.deck.length, attackerId: room.attackerId, defenderId: room.defenderId,
    turnId: room.turnId, phase: room.phase, message: room.message,
    turnEndsAt: room.turnEndsAt, winnerId: room.winnerId, loserId: room.loserId
  };
}
function emitRoom(room) {
  const state = publicState(room);
  room.players.forEach(p => io.to(p.id).emit("game:state", { ...state, you:p.id, hand:p.hand.map(safeCard) }));
  io.emit("lobby:update", lobbyList());
}
function lobbyList() {
  return [...rooms.values()].filter(r=>r.privacy==="public" && r.status!=="finished")
    .map(r=>({code:r.code, mode:r.mode, deckSize:r.deckSize, players:r.players.length, maxPlayers:2, status:r.status, bet:r.bet}));
}
function playerById(room,id) { return room.players.find(p=>p.id===id); }
function startTimer(room) {
  clearTimeout(timers.get(room.code));
  room.turnEndsAt = Date.now()+45000;
  timers.set(room.code,setTimeout(()=>{
    if (!rooms.has(room.code) || room.status!=="playing") return;
    const p=playerById(room,room.turnId);
    if (p) {
      if (room.phase==="defend") { room.message=`${p.name} ran out of time and picked up the table.`; takeTable(room,p); }
      else { room.message=`${p.name} timed out. Turn passed.`; room.turnId=room.defenderId; room.phase="attack"; }
      advanceAfterTimeout(room);
    }
  },45000));
}
function advanceAfterTimeout(room) {
  if (room.status!=="playing") return;
  startTimer(room); emitRoom(room);
}
function deal(room) {
  room.players.forEach(p=>{ while(p.hand.length<6 && room.deck.length) p.hand.push(room.deck.pop()); });
  if (room.trump && room.deck.length===0) return;
}
function chooseNext(room, id) {
  const idx=room.players.findIndex(p=>p.id===id);
  return room.players[(idx+1)%room.players.length]?.id;
}
function takeTable(room, player) {
  room.table.forEach(pair=>{ player.hand.push(pair.attack); if(pair.defense) player.hand.push(pair.defense); });
  room.table=[]; room.phase="attack"; room.attackerId=chooseNext(room,room.defenderId);
  room.defenderId=chooseNext(room,room.attackerId); room.turnId=room.attackerId;
  room.message=`${player.name} picked up the cards.`;
}
function finishRound(room) {
  if (room.deck.length===0) {
    const active=room.players.filter(p=>p.hand.length>0);
    if (active.length<=1) {
      room.status="finished"; room.winnerId=room.players.find(p=>p.hand.length===0)?.id || null;
      room.loserId=active[0]?.id || null;
      const winner=playerById(room,room.winnerId), loser=playerById(room,room.loserId);
      if(winner && loser){ winner.coins += room.bet; loser.coins=Math.max(0,loser.coins-room.bet); }
      room.message=winner ? `${winner.name} wins!` : "Round finished.";
      clearTimeout(timers.get(room.code)); return true;
    }
  }
  return false;
}
function afterDefense(room) {
  const defender=playerById(room,room.defenderId);
  if(room.table.length>=6 || !defender || defender.hand.length===0) {
    room.table=[]; room.attackerId=room.defenderId; room.defenderId=chooseNext(room,room.attackerId);
    room.turnId=room.attackerId; room.phase="attack"; room.message="Defense successful. New attack!";
    deal(room);
  } else {
    room.phase="attack"; room.turnId=room.attackerId; room.message="Defense successful. Attacker may add a card.";
  }
  if(!finishRound(room)) startTimer(room);
}
function isLegal(room, player, card, action) {
  const trumpSuit=room.trump?.suit;
  if(action==="attack") {
    if(player.id!==room.attackerId || room.phase!=="attack") return false;
    if(room.table.length===0) return true;
    const ranks=room.table.flatMap(x=>[x.attack.rank,x.defense?.rank].filter(Boolean));
    return ranks.includes(card.rank) && room.table.length<6;
  }
  if(action==="defend") {
    if(player.id!==room.defenderId || room.phase!=="defend") return false;
    const pair=room.table.find(x=>!x.defense);
    if(!pair) return false;
    return (card.suit===pair.attack.suit && VALUE[card.rank]>VALUE[pair.attack.rank]) ||
      (card.suit===trumpSuit && pair.attack.suit!==trumpSuit);
  }
  return false;
}
function removeCard(player,id) {
  const idx=player.hand.findIndex(c=>c.id===id);
  return idx<0 ? null : player.hand.splice(idx,1)[0];
}
function beginGame(room) {
  if(room.players.length!==2) return;
  room.deck=makeDeck(room.deckSize);
  room.players.forEach(p=>p.hand=[]);
  room.table=[]; room.trump=room.deck[0]; room.players.forEach(p=>{for(let i=0;i<6;i++)p.hand.push(room.deck.pop());});
  const low=room.players.map(p=>({id:p.id, value:Math.min(...p.hand.filter(c=>c.suit===room.trump.suit).map(c=>VALUE[c.rank]),99)})).sort((a,b)=>a.value-b.value);
  room.attackerId=low[0].id; room.defenderId=chooseNext(room,room.attackerId);
  room.turnId=room.attackerId; room.phase="attack"; room.status="playing"; room.message="Game started. Make your move!";
  startTimer(room); emitRoom(room);
}
io.on("connection", socket=>{
  socket.emit("lobby:update",lobbyList());
  socket.on("profile:set", data=>{
    const name=String(data?.name||"Player").trim().slice(0,18)||"Player";
    const avatar=String(data?.avatar||"🦊").slice(0,8);
    profiles.set(socket.id,{name,avatar,coins:profiles.get(socket.id)?.coins??1000});
    socket.emit("profile:ok",profiles.get(socket.id));
  });
  socket.on("lobby:list",()=>socket.emit("lobby:update",lobbyList()));
  socket.on("room:create", data=>{
    const profile=profiles.get(socket.id)||{name:"Player",avatar:"🦊",coins:1000};
    const roomCode=code();
    const room={code:roomCode,privacy:data?.privacy==="private"?"private":"public",
      deckSize:[52,36,24,16,14].includes(Number(data?.deckSize))?Number(data.deckSize):36,
      mode:data?.mode==="liar"?"liar":"fair",bet:Math.max(0,Math.min(10000,Number(data?.bet)||0)),
      players:[{id:socket.id,...profile,hand:[],connected:true}],deck:[],table:[],trump:null,
      status:"waiting",phase:"attack",turnId:null,attackerId:null,defenderId:null,message:"Waiting for an opponent…"};
    rooms.set(roomCode,room); socket.join(roomCode); socket.emit("room:joined",{code:roomCode}); emitRoom(room);
  });
  socket.on("room:join", raw=>{
    const room=rooms.get(String(raw||"").toUpperCase());
    if(!room || room.players.length>=2 || room.status==="playing"){socket.emit("toast","Room not found or already full.");return;}
    const profile=profiles.get(socket.id)||{name:"Player",avatar:"🦊",coins:1000};
    room.players.push({id:socket.id,...profile,hand:[],connected:true}); socket.join(room.code);
    socket.emit("room:joined",{code:room.code}); beginGame(room);
  });
  socket.on("game:start",()=>{
    const room=[...rooms.values()].find(r=>r.players.some(p=>p.id===socket.id));
    if(room && room.players.length===2 && room.status==="waiting") beginGame(room);
  });
  socket.on("card:play", data=>{
    const room=[...rooms.values()].find(r=>r.players.some(p=>p.id===socket.id));
    if(!room || room.status!=="playing") return;
    const player=playerById(room,socket.id), card=player && player.hand.find(c=>c.id===data?.cardId);
    if(!player || !card) return;
    const action=data?.action==="defend"?"defend":"attack";
    const legal=isLegal(room,player,card,action);
    if(room.mode==="fair" && !legal){socket.emit("toast","That move isn't allowed in Fair Mode.");return;}
    if(room.mode==="liar") {
      // Any opponent response/action finalizes earlier cards; only the newest card remains challengeable.
      room.table.forEach(pair=>{pair.challengeable=false;});
    }
    const played=removeCard(player,card.id);
    if(!played)return;
    if(action==="defend" && room.table.some(x=>!x.defense)) {
      const pair=room.table.find(x=>!x.defense);
      pair.defense=played; pair.defenseIllegal=!legal; pair.defensePlayedBy=player.id;
      pair.challengeable=room.mode==="liar"; pair.illegal=!legal; pair.playedBy=player.id;
      room.phase="attack"; room.turnId=room.attackerId;
      if(legal) room.message=`${player.name} defended.`;
      else room.message=`${player.name} played a suspicious card! Tap it to challenge.`;
    } else {
      const pair={attack:played,defense:null,illegal:!legal,challengeable:room.mode==="liar",playedBy:player.id};
      room.table.push(pair); room.phase="defend"; room.turnId=room.defenderId;
      room.message=legal?`${player.name} attacked.`:`${player.name} played a suspicious card! Tap it to challenge.`;
    }
    if(!legal && room.mode==="liar") {
      // Keep the challenged card visible and give the opponent a chance to react.
      room.pendingBluff={playerId:player.id,cardId:played.id};
    }
    startTimer(room); emitRoom(room);
  });
  socket.on("card:challenge", data=>{
    const room=[...rooms.values()].find(r=>r.players.some(p=>p.id===socket.id));
    if(!room || room.mode!=="liar" || room.status!=="playing") return;
    const pair=room.table.find(x=>x.attack.id===data?.cardId || x.defense?.id===data?.cardId);
    if(!pair || !pair.challengeable || pair.playedBy===socket.id) return;
    const accuser=playerById(room,socket.id);
    const illegal=!!pair.illegal;
    if(illegal) {
      const cheater=playerById(room,pair.playedBy);
      if(cheater) takeTable(room,cheater);
      room.message=`Caught! ${cheater?.name||"The player"} takes the table.`;
    } else {
      takeTable(room,accuser);
      room.message=`False accusation! ${accuser.name} takes the table.`;
    }
    room.pendingBluff=null; startTimer(room); emitRoom(room);
  });
  socket.on("game:pickup",()=>{
    const room=[...rooms.values()].find(r=>r.players.some(p=>p.id===socket.id));
    if(!room || room.status!=="playing" || room.phase!=="defend" || room.defenderId!==socket.id)return;
    takeTable(room,playerById(room,socket.id)); deal(room); finishRound(room); startTimer(room); emitRoom(room);
  });
  socket.on("game:pass",()=>{
    const room=[...rooms.values()].find(r=>r.players.some(p=>p.id===socket.id));
    if(!room || room.status!=="playing" || room.turnId!==socket.id || room.phase!=="attack" || room.table.length===0)return;
    // Passing ends the attack; unresolved bluffs are no longer challengeable.
    room.table.forEach(x=>x.challengeable=false);
    room.table=[]; room.attackerId=room.defenderId; room.defenderId=chooseNext(room,room.attackerId);
    room.turnId=room.attackerId; room.phase="attack"; room.message="Cards cleared. New attack!";
    deal(room); finishRound(room); startTimer(room); emitRoom(room);
  });
  socket.on("chat:reaction", emoji=>{
    const room=[...rooms.values()].find(r=>r.players.some(p=>p.id===socket.id));
    if(room && ["😂","😎","🤥","😱","👏","🔥","❤️","😈"].includes(emoji))
      io.to(room.code).emit("chat:reaction",{playerId:socket.id,emoji});
  });
  socket.on("game:rematch",()=>{
    const room=[...rooms.values()].find(r=>r.players.some(p=>p.id===socket.id));
    if(room && room.status==="finished" && room.players.length===2) {
      room.status="waiting"; room.winnerId=null;room.loserId=null;room.players.forEach(p=>p.hand=[]);room.message="Rematch requested. Starting…";beginGame(room);
    }
  });
  socket.on("disconnect",()=>{
    for(const [key,room] of rooms) {
      const p=playerById(room,socket.id);
      if(p){p.connected=false;room.message=`${p.name} disconnected. Room will remain open briefly.`;emitRoom(room);
        setTimeout(()=>{const r=rooms.get(key);if(r&&playerById(r,socket.id)&&!playerById(r,socket.id).connected){clearTimeout(timers.get(key));rooms.delete(key);io.emit("lobby:update",lobbyList());}},120000);}
    }
  });
});

server.listen(PORT,()=>console.log(`Durak Online running on ${PORT}`));
